import os

def process_data(link):
	pass

def recursion(link):
    if os.path.isfile(link):
        process_data(link)
    else:
        for ld in os.listdir(link):
            recursion(f'{link}/{ld}')

recursion(".")